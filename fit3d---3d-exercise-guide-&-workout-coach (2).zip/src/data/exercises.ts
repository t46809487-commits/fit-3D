import { Exercise, BoxingCombo } from '../types';

export const EXERCISES_DATABASE: Exercise[] = [
  // CHEST
  {
    id: 'EX001',
    name: 'Standard Push-Up',
    category: 'Chest',
    goals: ['Fat Loss', 'Build Muscle', 'Chest'],
    bodyPart: 'Chest',
    difficulty: 'Beginner',
    equipment: ['No Equipment'],
    primaryMuscles: ['mid_chest_l', 'mid_chest_r', 'lower_chest_l', 'lower_chest_r'],
    secondaryMuscles: ['triceps_l', 'triceps_r', 'front_delts_l', 'front_delts_r', 'rectus_abdominis'],
    movementPattern: 'Horizontal Push',
    instructions: [
      'Assume a rigid plank position with palms planted slightly wider than shoulder-width.',
      'Squeeze glutes and draw navel toward spine to maintain unbroken spinal alignment.',
      'Descend under control until sternum grazes the floor at a 45-degree elbow angle.',
      'Press through the base of palms to lockout at the top.'
    ],
    commonMistakes: [
      'Sagging hips putting shear on lumbar spine.',
      'Flaring elbows out perpendicular at 90 degrees.',
      'Craning neck forward toward the ground.'
    ],
    breathingPattern: 'Inhale on the descent; exhale forcefully on the upward pressing drive.',
    animationId: 'ex_pushup_rep',
    animationType: 'pushup',
    characterId: 'CHAR-M-01',
    tempo: '2-0-1',
    reps: 12,
    sets: 3,
    restSeconds: 45,
    caloriesEstimate: 36,
  },
  {
    id: 'EX002',
    name: 'Incline Push-Up',
    category: 'Chest',
    goals: ['Fat Loss', 'Chest'],
    bodyPart: 'Chest',
    difficulty: 'Beginner',
    equipment: ['No Equipment'],
    primaryMuscles: ['lower_chest_l', 'lower_chest_r'],
    secondaryMuscles: ['triceps_l', 'triceps_r', 'front_delts_l', 'front_delts_r'],
    movementPattern: 'Horizontal Push Angle',
    instructions: [
      'Place hands on a stable bench or elevated box shoulder-width apart.',
      'Maintain head-to-heel plank rigidity.',
      'Lower chest to edge of surface, then press back to start.'
    ],
    commonMistakes: [
      'Piking hips upward instead of keeping plank.',
      'Rushing repetitions without eccentric control.'
    ],
    breathingPattern: 'Inhale down, exhale up.',
    animationId: 'ex_incline_pushup_rep',
    animationType: 'pushup',
    characterId: 'CHAR-M-01',
    tempo: '2-0-2',
    reps: 15,
    sets: 3,
    restSeconds: 30,
    caloriesEstimate: 28,
  },
  {
    id: 'EX003',
    name: 'Dumbbell Chest Press',
    category: 'Chest',
    goals: ['Build Muscle', 'Chest'],
    bodyPart: 'Chest',
    difficulty: 'Intermediate',
    equipment: ['Dumbbells'],
    primaryMuscles: ['mid_chest_l', 'mid_chest_r', 'upper_chest_l', 'upper_chest_r'],
    secondaryMuscles: ['triceps_l', 'triceps_r', 'front_delts_l', 'front_delts_r'],
    movementPattern: 'Horizontal Free-Weight Press',
    instructions: [
      'Lie flat on bench with dumbbells positioned over chest, palms facing forward.',
      'Retract scapulae firmly against bench surface.',
      'Lower weights with elbows at 45-60 degrees until bells reach chest height.',
      'Drive dumbbells upward in slight convergence without banging weights.'
    ],
    commonMistakes: [
      'Excessive hyperextension of lumbar spine.',
      'Bouncing weights off chest.'
    ],
    breathingPattern: 'Inhale lowering dumbbells, exhale driving overhead.',
    animationId: 'ex_db_press_rep',
    animationType: 'pushup',
    characterId: 'CHAR-M-01',
    tempo: '3-1-1',
    reps: 10,
    sets: 4,
    restSeconds: 60,
    caloriesEstimate: 45,
  },

  // ARMS
  {
    id: 'EX004',
    name: 'Standing Bicep Curl',
    category: 'Arms',
    goals: ['Build Muscle', 'Arms'],
    bodyPart: 'Arms',
    difficulty: 'Beginner',
    equipment: ['Dumbbells'],
    primaryMuscles: ['biceps_l', 'biceps_r'],
    secondaryMuscles: ['forearms_l', 'forearms_r'],
    movementPattern: 'Elbow Flexion',
    instructions: [
      'Stand upright with feet shoulder-width apart, holding dumbbells at sides.',
      'Keep upper arms pinned stationary against ribcage.',
      'Curl dumbbells upward while supinating wrists so palms face shoulders at peak.',
      'Squeeze biceps for 1 second, then lower under 2-second eccentric tempo.'
    ],
    commonMistakes: [
      'Rocking hips or using torso momentum to swing weights.',
      'Elbows drifting forward during flexion.'
    ],
    breathingPattern: 'Exhale curling up; inhale smoothly lowering down.',
    animationId: 'ex_bicep_curl_rep',
    animationType: 'bicep_curl',
    characterId: 'CHAR-M-01',
    tempo: '2-1-2',
    reps: 12,
    sets: 3,
    restSeconds: 45,
    caloriesEstimate: 32,
  },
  {
    id: 'EX005',
    name: 'Diamond Push-Up',
    category: 'Arms',
    goals: ['Build Muscle', 'Arms', 'Chest'],
    bodyPart: 'Arms',
    difficulty: 'Intermediate',
    equipment: ['No Equipment'],
    primaryMuscles: ['triceps_l', 'triceps_r'],
    secondaryMuscles: ['mid_chest_l', 'mid_chest_r', 'front_delts_l', 'front_delts_r'],
    movementPattern: 'Close-Grip Push',
    instructions: [
      'Position index fingers and thumbs touching in a diamond shape beneath center chest.',
      'Lower body slowly until chest touches hands.',
      'Press upward locking out triceps.'
    ],
    commonMistakes: [
      'Flaring elbows out; keep them tracking back toward hips.',
      'Sagging midsection.'
    ],
    breathingPattern: 'Inhale descending, exhale locking out.',
    animationId: 'ex_diamond_pushup_rep',
    animationType: 'pushup',
    characterId: 'CHAR-M-01',
    tempo: '2-0-1',
    reps: 10,
    sets: 3,
    restSeconds: 60,
    caloriesEstimate: 38,
  },

  // LEGS
  {
    id: 'EX007',
    name: 'Bodyweight Squat',
    category: 'Legs',
    goals: ['Fat Loss', 'Build Muscle', 'Legs'],
    bodyPart: 'Legs',
    difficulty: 'Beginner',
    equipment: ['No Equipment'],
    primaryMuscles: ['quads_l', 'quads_r', 'glutes_l', 'glutes_r'],
    secondaryMuscles: ['hamstrings_l', 'hamstrings_r', 'calves_l', 'calves_r', 'rectus_abdominis'],
    movementPattern: 'Squat / Bilateral Knee Flexion',
    instructions: [
      'Stand with feet shoulder-width apart, toes turned slightly out 15 degrees.',
      'Break simultaneously at hips and knees while maintaining upright chest.',
      'Descend until crease of hip is at or below top of patella.',
      'Drive through mid-foot and heel to stand tall, contracting glutes at lockout.'
    ],
    commonMistakes: [
      'Knees collapsing inward (valgus collapse).',
      'Heels lifting off the ground.',
      'Rounding lumbar spine at depth.'
    ],
    breathingPattern: 'Inhale deeply during descent; exhale forcefully driving through the floor.',
    animationId: 'ex_squat_rep',
    animationType: 'squat',
    characterId: 'CHAR-M-01',
    tempo: '3-0-1',
    reps: 15,
    sets: 3,
    restSeconds: 45,
    caloriesEstimate: 42,
  },
  {
    id: 'EX008',
    name: 'Walking Lunges',
    category: 'Legs',
    goals: ['Fat Loss', 'Legs'],
    bodyPart: 'Legs',
    difficulty: 'Intermediate',
    equipment: ['No Equipment'],
    primaryMuscles: ['quads_l', 'quads_r', 'glutes_l', 'glutes_r'],
    secondaryMuscles: ['hamstrings_l', 'hamstrings_r', 'calves_l', 'calves_r'],
    movementPattern: 'Unilateral Knee Flexion',
    instructions: [
      'Take a controlled stride forward, landing heel-first.',
      'Lower torso until front thigh is parallel to ground and trailing knee hovers 1 inch off floor.',
      'Drive through front heel to step forward into the opposite leg stride.'
    ],
    commonMistakes: [
      'Front knee pushing excessively far beyond toes.',
      'Torso collapsing forward onto front thigh.'
    ],
    breathingPattern: 'Inhale descending, exhale stepping forward.',
    animationId: 'ex_lunge_rep',
    animationType: 'lunges',
    characterId: 'CHAR-M-01',
    tempo: '2-0-1',
    reps: 20,
    sets: 3,
    restSeconds: 45,
    caloriesEstimate: 50,
  },

  // BACK
  {
    id: 'EX010',
    name: 'Pull-Up',
    category: 'Back',
    goals: ['Build Muscle', 'Back'],
    bodyPart: 'Back',
    difficulty: 'Advanced',
    equipment: ['No Equipment'],
    primaryMuscles: ['lats_l', 'lats_r', 'traps'],
    secondaryMuscles: ['biceps_l', 'biceps_r', 'rear_delts_l', 'rear_delts_r'],
    movementPattern: 'Vertical Pull',
    instructions: [
      'Hang from bar with overhand grip slightly wider than shoulders.',
      'Depress shoulder blades down away from ears.',
      'Drive elbows down toward waist until chin cleanly clears the bar.',
      'Lower with control back to a full dead hang.'
    ],
    commonMistakes: [
      'Kipping or swinging legs for false momentum.',
      'Short reps without reaching full dead-hang stretch.'
    ],
    breathingPattern: 'Inhale at bottom hang; exhale driving elbows down.',
    animationId: 'ex_pullup_rep',
    animationType: 'pushup',
    characterId: 'CHAR-M-01',
    tempo: '2-1-2',
    reps: 8,
    sets: 3,
    restSeconds: 60,
    caloriesEstimate: 40,
  },

  // SHOULDERS
  {
    id: 'EX012',
    name: 'Overhead Shoulder Press',
    category: 'Shoulders',
    goals: ['Build Muscle', 'Shoulders'],
    bodyPart: 'Shoulders',
    difficulty: 'Intermediate',
    equipment: ['Dumbbells'],
    primaryMuscles: ['front_delts_l', 'front_delts_r', 'side_delts_l', 'side_delts_r'],
    secondaryMuscles: ['triceps_l', 'triceps_r', 'traps', 'upper_chest_l', 'upper_chest_r'],
    movementPattern: 'Vertical Push',
    instructions: [
      'Hold dumbbells at ear height with palms facing forward, core braced tight.',
      'Press weights overhead along scapular plane until arms are fully extended.',
      'Lower smoothly back to starting ear height under 2-second control.'
    ],
    commonMistakes: [
      'Excessive arching of lumbar spine.',
      'Pressing dumbbells out in front instead of directly in line with spine.'
    ],
    breathingPattern: 'Exhale pressing overhead, inhale lowering down.',
    animationId: 'ex_overhead_press_rep',
    animationType: 'overhead_press',
    characterId: 'CHAR-M-01',
    tempo: '2-1-1',
    reps: 10,
    sets: 3,
    restSeconds: 60,
    caloriesEstimate: 36,
  },

  // ABS / CORE
  {
    id: 'EX014',
    name: 'Abdominal Crunch',
    category: 'Abs',
    goals: ['Build Abs', 'Fat Loss'],
    bodyPart: 'Abs',
    difficulty: 'Beginner',
    equipment: ['No Equipment'],
    primaryMuscles: ['rectus_abdominis', 'abs'],
    secondaryMuscles: ['obliques_l', 'obliques_r'],
    movementPattern: 'Spinal Flexion',
    instructions: [
      'Lie supine with knees bent at 90 degrees and soles flat.',
      'Support neck gently with fingertips behind ears.',
      'Curl scapulae off the floor by contracting rectus abdominis.',
      'Pause at peak contraction for 1 second, then unroll spine slowly.'
    ],
    commonMistakes: [
      'Yanking neck forward with hands.',
      'Pulling up with hip flexors instead of curling the abdominal wall.'
    ],
    breathingPattern: 'Exhale sharply on contraction; inhale lowering down.',
    animationId: 'ex_crunch_rep',
    animationType: 'crunch',
    characterId: 'CHAR-M-01',
    tempo: '2-1-2',
    reps: 15,
    sets: 3,
    restSeconds: 30,
    caloriesEstimate: 25,
  },

  // BOXING STRIKES (PRD v2.0 Section 18: Unilateral Precision)
  {
    id: 'BX001',
    name: 'Boxing - Jab (1)',
    category: 'Boxing',
    goals: ['Boxing', 'Fat Loss'],
    bodyPart: 'Boxing',
    difficulty: 'Beginner',
    equipment: ['No Equipment'],
    primaryMuscles: ['front_delts_l', 'triceps_l'], // Unilateral left side!
    secondaryMuscles: ['obliques_l', 'calves_l', 'mid_chest_l'],
    movementPattern: 'Lead Hand Straight Strike',
    instructions: [
      'From boxing stance, snap lead left hand straight down centerline.',
      'Rotate fist so palm faces down at full extension.',
      'Retract instantly back to high guard cheekbone.'
    ],
    commonMistakes: [
      'Dropping rear right hand while throwing jab.',
      'Overreaching past center of balance.'
    ],
    breathingPattern: 'Sharp, explosive exhale "Tsssh!" on strike.',
    animationId: 'box_jab_clip',
    animationType: 'box_jab',
    characterId: 'CHAR-M-01',
    tempo: '1-0-1',
    reps: 20,
    sets: 3,
    restSeconds: 30,
    caloriesEstimate: 32,
  },
  {
    id: 'BX002',
    name: 'Boxing - Cross (2)',
    category: 'Boxing',
    goals: ['Boxing', 'Fat Loss'],
    bodyPart: 'Boxing',
    difficulty: 'Beginner',
    equipment: ['No Equipment'],
    primaryMuscles: ['front_delts_r', 'mid_chest_r', 'obliques_r'], // Unilateral right side!
    secondaryMuscles: ['triceps_r', 'calves_r', 'glutes_r'],
    movementPattern: 'Rear Hand Power Punch',
    instructions: [
      'Pivot rear right foot and rotate right hip forward into centerline.',
      'Fire right straight punch with shoulder guarding right jaw.',
      'Snap back instantly into defensive guard.'
    ],
    commonMistakes: [
      'Arm punching without rotating hip and foot.',
      'Leaving rear heel flat on the canvas.'
    ],
    breathingPattern: 'Power hiss "Tsssh!" as hip transfers kinetic force.',
    animationId: 'box_cross_clip',
    animationType: 'box_cross',
    characterId: 'CHAR-M-01',
    tempo: '1-0-1',
    reps: 20,
    sets: 3,
    restSeconds: 30,
    caloriesEstimate: 38,
  }
];

export const BOXING_COMBOS: BoxingCombo[] = [
  {
    id: 'BC001',
    name: '1-2 Basic: The Foundation',
    sequence: [1, 2],
    description: 'Jab measures range and blinds opponent, followed by laser rear power Cross.',
    difficulty: 'Beginner',
    targetRounds: 3,
    roundTimeSeconds: 180,
    calories: 180
  },
  {
    id: 'BC002',
    name: '1-2-3 Classic Heavy Hook',
    sequence: [1, 2, 3],
    description: 'Jab, Cross, and finish with a devastating left hook around opponent guard.',
    difficulty: 'Intermediate',
    targetRounds: 4,
    roundTimeSeconds: 180,
    calories: 250
  },
  {
    id: 'BC003',
    name: '1-2-3-2 Rapid Fire Flurry',
    sequence: [1, 2, 3, 2],
    description: 'Jab, Cross, Left Hook, and re-anchor with snapping rear Cross.',
    difficulty: 'Intermediate',
    targetRounds: 5,
    roundTimeSeconds: 180,
    calories: 320
  },
  {
    id: 'BC004',
    name: '1-6-3 Body & Head Breaker',
    sequence: [1, 6, 3],
    description: 'Jab sets up a rising right uppercut inside guard, finished by sharp left hook.',
    difficulty: 'Advanced',
    targetRounds: 4,
    roundTimeSeconds: 180,
    calories: 280
  }
];
